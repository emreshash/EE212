#ifndef ADC_H
#define ADC_H
 
// Include Files
#include <stdint.h>
 
/**************************************************
Global Function Prototypes
***************************************************/
void init_ADC(void);
uint16_t adc_read(uint8_t ch);
 
#endif  // end of ADC_H